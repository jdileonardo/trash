/* Filename: deepthroat.c
 * Author: Julian Di Leonardo
 * ID:0675743
 * Date:February 6th, 2011
 * Class: CIS 3110
 * Assignment 1(Part 1 of 2)
 * 
 * Description: Acts as a server to intake a message and send it to "thewashingtonpost.c"
 */
#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
#include <time.h> 
//#include <stdlib.h>


void SIGQUIT_handler( int signum);
void SIGUSR1_handler( int signum );
void SIGUSR2_handler( int signum );
void SIGALRM_handler( int signum);
void SIGTERM_handler (int signum);

int getMessage();
int sendMessage();
int randomgen(int value);
int wp_pid;//Holds TheWashingtonPost's PID for Global Use
int flag;//Used to detect when a signal has been sent back
char returnedVal;//The returned value from WashingtonPost after a binary signal
char trueVal; // The value (0/1) which is being passed to Washington Post
int passwordManage(char value);
char buf[256];//Holds the PID of WashingtonPost temporarily
char password[4] = "";//The password thats sent from Washington Post


int main()
{
	int dt_pid = getpid();//Deepthroat's own PID
	signal(SIGQUIT, SIGQUIT_handler);
	signal(SIGUSR1, SIGUSR1_handler);
	signal(SIGUSR2, SIGUSR2_handler);
	signal(SIGALRM, SIGALRM_handler);
	signal(SIGTERM, SIGTERM_handler);
	
	printf("My PID = %d\n", getpid() );
	while(1)
	{
		printf("\nIDLE\n");//Dormant state of program
		sleep(10);
	}
	return(0);

}

void SIGQUIT_handler( int signum )//Handles Washington Post's Initial wakeup
{
	printf("Contact with");
	FILE *fp = popen("pidof thewashingtonpost","r");
	fgets(buf,sizeof buf, fp);
	wp_pid = atoi(buf);
	printf("PID  at [%d],Asking for Password\n",wp_pid);
	kill(wp_pid,SIGALRM);//Ask's washington post to begin sending the password
}

int passwordManage(char value)//Verifies that the bits being sent correspond with the preset password
{
	int size = strlen(password);//Adding bits to chararray
	password[size] = value;
	password[size+1] = '\0';//compensating for overwriting '\0' with each new addition
	if(strcmp(password,"1001") == 0)//if the char array matches the actually password
	{
		printf("Password Accepted\nHello Washington\n");
		memset(password,0,sizeof(password));
		getMessage();//Now time to get Message
	}
	else if(strlen(password) == 4){//If it eqausl 4 but doesnt match
		memset(password,0,sizeof(password));
		printf("Invalid Password!!\n");
		kill(wp_pid,SIGALRM);//Ask for Password again
		}

}
void SIGUSR1_handler( int signum )//Password specific bit
{
	printf("Transmitting Password [0]\n");
	passwordManage('0');
}

void SIGUSR2_handler( int signum )//Password specific bit
{
	printf("Transmitting Password [1]\n");
	passwordManage('1');
}
int getMessage ()//Grabs input from user entered into terminal, breaks it down into bits
{
	char msg[256];
	printf("Enter Message:");
	int c;
	while((c = getchar()))//automatically returns ascii value
	{
		int mask = 128;
		if(c == 10)//if its end of line
		{
			kill(wp_pid,SIGTERM);//Tells Washingtonpost the message transfer is over
			usleep(5000);
			break;
		}
		while(mask > 0)//Beggining of Reference 1; See Documentaion
		{
			if ((c & mask) == 0) // Breaks the ascii value, into an 8 bits, transfers bit by bit to sendMessage
			{
				sendMessage(0);
			}
			else
			{
				sendMessage(1);
			}
			mask = mask >> 1;
		}//End of Reference 1
	}
}

int randomgen(int value)//Generates Random events: Normal,Flip,and Drop Signal
{
	while(1)
	{
		int x;
		srand(time(NULL));
		x = rand()%3;
		if(x == 0)//Go as normal
		{
			return(value);
		}
		else if(x == 1)//Flip Bit
		{
			printf("FLIPPING[Teehee]\n");
			if(trueVal == 0)
			{
				
				return(1);
			}
			else if(trueVal == 1)
			{
				return(0);
			}
		}
		else if(x == 2)//Not sending this time
		{
			printf("BIT DROPPED[ :( ]\n");
			sleep(1);
			continue;
		}
	}
}
int sendMessage(int value)
{
	trueVal = value;//Track Real Value
	
	while(1)
	{
		
		int tempval = randomgen(value);//returns the modified orginal value

		if( (returnedVal == trueVal) && (flag == 1)){
			printf("SUCCESS\n");//acnowledges that washingtonpost got the correct val; no errors
			flag = 0;
			break;
			
		}
		else if ((returnedVal != trueVal) && (flag == 1))
		{
			printf("FAIL\n");
			flag = 0;
			kill(wp_pid,SIGQUIT);//Tells washingtonpost to delete last bit sent
			usleep(5000);
			continue;
		}
		
		if(tempval == 0)
		{
			printf("Sending a 0! --> ");
			kill(wp_pid, SIGUSR1);//Sends a 0
			usleep(5000);
		}
	
		if(tempval == 1)
		{
			printf("Sending a 1! --> ");
			kill(wp_pid, SIGUSR2);//Sends a 1
			usleep(5000);
		}
	}
}

void SIGTERM_handler( int signum)//Handles washington post returing a 0
{
	printf("Recieved a 0\n");
	flag = 1;//flag that we've got a message back
	returnedVal = 0;
}

void SIGALRM_handler( int signum)//handles washingtonpost returing a 1
{
	printf("Received a 1\n");
	flag = 1;
	returnedVal = 1;
}
