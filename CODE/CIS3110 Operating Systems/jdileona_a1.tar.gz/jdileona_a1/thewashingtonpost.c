/* Filename: thewashingtonpost.c
 * Author: Julian Di Leonardo
 * ID:0675743
 * Date:February 6th, 2011
 * Class: CIS 3110
 * Assignment 1(Part 2 of 2)
 * 
 * Description: Acts as a client to intake a message from send "deepthroat" and display it in terminal
 */
#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
//#include <stdlib.h>
void SIGUSR1_handler( int signum );
void SIGUSR2_handler( int signum );
void SIGQUIT_handler( int signum);
void SIGALRM_handler( int signum);
void SIGTERM_handler( int signum);
char binletter[8];//holds each characters 8 bits
char buf[256];//holds recieved message
char pidholder[20];//holds Deepthroats pid
int formMessage();
int dt_pid = 0;

int main()
{
	
	signal(SIGUSR1, SIGUSR1_handler);
	signal(SIGUSR2, SIGUSR2_handler);
	signal(SIGALRM, SIGALRM_handler);
	signal(SIGTERM, SIGTERM_handler);
	signal(SIGQUIT, SIGQUIT_handler);
	int wp_pid = getpid();
	printf("My PID = %d\n", getpid());
	
	if(dt_pid == 0)//Having issues with changing the PID, so i only find it once
	{
		
		FILE *fp = popen("pidof deepthroat","r");
		while(fgets(pidholder,sizeof pidholder, fp))
		{
			dt_pid = atoi(pidholder);
			printf("DeepThroat PID: %d\n",dt_pid);
			
		}
		
		kill(dt_pid, SIGQUIT);//Informs Deepthroat its awake
		
	}
	while(1)//dormant state
	{
		printf("\nIDLE\n");
		sleep(10);	
	}
	return(0);
}

void SIGUSR1_handler( int signum )
{
	printf("Recieved a 0\n");
	// send signal 0 back
	kill(dt_pid, SIGTERM);
	formMessage('0');
	usleep(1000);
}

void SIGUSR2_handler( int signum )
{
	printf("Recieved a 1\n");
	//send signal 1 back
	kill(dt_pid, SIGALRM);
	formMessage('1');
	usleep(1000);

}
void SIGTERM_handler( int signum)//Prints off final message
{
	printf("\nMESSAGE TRANMISSION COMPLETE\n MESSAGE: [%s]\n",buf);
	memset(buf,0,sizeof(buf));
	raise(SIGALRM);//signals password send again, for another message transfer
}

void SIGALRM_handler( int signum)
{
	printf("Sending Password to %d\n",dt_pid);
	kill(dt_pid, SIGUSR2);//1
	usleep(1000);
	kill(dt_pid, SIGUSR1);//0
	usleep(1000);
	kill(dt_pid, SIGUSR1);//0
	usleep(1000);
	kill(dt_pid, SIGUSR2);//1
	usleep(1000);
}
void SIGQUIT_handler( int signum)
{
	printf("Oops! Bad Signal\n");//removes newly added char from 8bitchar array, as it was wrong
	int size = strlen(binletter);
	
	binletter[size-1] = '\0';
	
	
}


int formMessage(int value)
{
	int size = strlen(binletter);//adds transferred bit to char array
	binletter[size] = value;
	binletter[size+1] = '\0';
	
	if( 8 == strlen(binletter))//when the char array hits its max
	{
		int i;
		int decimal = 0;
		int factor = 128;
		int charnum;
		for (i = 0; i < 8; i++)//convert back to ascii value
		{
			int digit = ((int)binletter[i] - 48);
			decimal = decimal + (digit * factor);
			factor = factor/2;
			charnum = decimal;
		}
	
		int size = strlen(buf);
		buf[size] = (char)charnum;//decimal back into char
		buf[size+1] = '\0';
		memset(binletter,0,sizeof(binletter));
		}
}
