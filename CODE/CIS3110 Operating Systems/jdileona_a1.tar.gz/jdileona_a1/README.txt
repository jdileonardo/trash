Author: Julian Di Leonardo
ID:0675743
Date:February 6th, 2011
Class: CIS 3110

FILES:

deepthroat.c - The "informant", after password verification with the washington post
recieves the message from stdin, and send it to thewashingtonpost.
 
thewashingonpost.c - The "reciever", recieves the message and prints it to stdin.

Compilation:
Open a terminal;
type: make
type: ./deepthroat

and in the other
type: ./thewashingtonpost

Notes for Marker:

-I was having issue with timing when moving to the machines in the lab
they seemed to throw alot off, and sometimes the bits would transfer, but my end message
would be complete garbage.(It may have to do with the speeds of these machines?).
for the record, the program worked fine on my mac, with a vm of ubuntu 10.10

-When testing, if the output of washington comes out wrong, end both process and restart each
 because if it comes out wrong once, it wont print out correctly again

-It forsure works when all the bits are normally sent, 
and sometimes works when the rand either drops or flips the bits, but does work.

-HOWEVER, one issue i MAY have not accounted for, is if on the 8th bit, deepthroat sends
the wrong one. This will cause washington to develop the message, with the wrong bit.
I am not sure if this is actually occuring or not

Thanks for reading