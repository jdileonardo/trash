/* Filename: resec.c
 * Author: Julian Di Leonardo
 * ID:0675743
 * Date:April 3rd, 2011
 * Class: CIS 3110
 * Assignment 3(Part 1 of 2)
 * 
 * Description: The client which communicates with the server
 */

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <netdb.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <time.h>
#include <fcntl.h>
#include <sys/stat.h>

#define ERROR(x) do { perror(x); exit(1); } while(0)

#define BUFSIZE 257
#define MAXSTR 1025
#define DEBUG 0

/*Predefined structures from Assignmeant*/
typedef enum { LIS, GET, PUT, EXE, ACK, ERR } PacketType;

typedef struct
{
    PacketType type;
    int size;
    int perm;
    char text[MAXSTR];
} packet;

int main(int argc, char *argv[])
{
	char *hostname;			/* Host on which to connect to server */
	unsigned short port;	/* Port on which server is listening  */
	int S;					/* fd for socket */

	struct sockaddr_in sock;	/* INTERNET socket space */
	struct hostent *remote;		/* Remote host information */


	if (argc < 3)/*Minimum amount of arguments required to run*/
	{
		printf("Not Enough Arguments");
		return(0);
	}
	hostname = argv[2];
	
	if(strcmp(argv[1],"-t") == 0)
	{
		port = 3000;
	}
	else if(strcmp(argv[1],"-f") == 0)
	{
		port = 3001;
	}
	else if(strcmp(argv[1],"-e") == 0)
	{
		port = 3002;
	}
	else
	{
			printf("\nMalformed Request; [%s] is not a valid flag\nCheck User Documentation For Help\n",argv[1]);
			return(0);
	}
	
	/*
	 * Obtain socket - INTERNET DOMAIN - TCP
	 */
	if ((S = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		ERROR("client: socket");

	/*
	 * Get network address of server
	 */
	if ((remote = gethostbyname(hostname)) == NULL)
	{
		fprintf(stderr,"%s: unknown host\n", hostname);
		exit(1);
	}

	/*
	 * Set address of server - converting to network byte order
	 */
	sock.sin_family = AF_INET;
	sock.sin_port = htons(port);
	memcpy(&sock.sin_addr,remote->h_addr,remote->h_length);

	/*
	 * Attempt connection to server - must be listening for success
	 */
	if (connect(S, (struct sockaddr *)&sock, sizeof(sock)) < 0)
		ERROR("client: connect");
		
		
	if(port == 3000)/*Time Protocol*/
	{
		char buff[26];
		bzero(buff,25);
		read(S,buff,26);
		printf("%s",buff);
	}
	
	else if(port == 3001)/*Protocol for File Services*/
	{
		if(argc < 4)
		{
		    printf("Not Enough Arguments\n");
		    return(0);
		}
		if (strcmp(argv[3],"list") == 0)
		{
			char buff[BUFSIZE];
			packet req = {LIS,0,0,""};
			packet res;
			write(S,&req,sizeof(packet));/*Write and Recieve initial request and response*/
			read(S,&res,sizeof(packet));
			int bytesRead = 0;
			if(res.type == ACK)
			{
				while ((bytesRead = read(S,&buff,BUFSIZE)) > 0) {/*Read in the output of ls -1*/
				write(1,&buff,bytesRead);
				}
			}
			else/*error occured*/
			{
				printf("%s",res.text);
			}
		}
		else if (strcmp(argv[3],"get") == 0)
		{
			struct stat st;
			int ret = stat(argv[4],&st);
			if((!(ret == -1)) && (!(st.st_mode & S_IWUSR)))
			{
			      printf("File exists on Client, Not Replaceable\n");
			      return(0);
			}

			
			packet req = {GET,0,0,""};
			strcpy(req.text,argv[4]);
			
			packet res;
			
			write(S,&req,sizeof(packet));/*Write and Recieve initial response*/
			read(S,&res,sizeof(packet));
			if(res.type == ERR)
			{
				printf("%s",res.text);
			}
			if(res.type == ACK)
			{
				int perm = res.perm;
				int size = res.size;

				char buffer[BUFSIZE];
				memset(buffer,'\0',BUFSIZE);
				int readbytes = 0;

				int writebytes = 0;
				int totalbytes = 0;
				
				if (DEBUG == 1)
				printf("SIZE IS %d\n", size);
				

				if(DEBUG == 1)
					printf("Permissions[%d]\n",perm);

				int fp = open(req.text,O_WRONLY | O_CREAT,S_IWUSR);/*Create the file with read permissions*/
				
				while((readbytes = read(S,&buffer,BUFSIZE)) > 0 && (totalbytes) < size)/*Read from socket until we've read the size*/
				{
					writebytes = write(fp,&buffer,readbytes);/*write the file all thats been read*/
					memset(buffer,'\0',BUFSIZE);
					totalbytes += readbytes;
					if(DEBUG == 1)
					{
						printf("Write %d\n",writebytes);
						printf("READ %d\n",readbytes);
					}
				}
				
				if(DEBUG == 1)
				{
					printf("Buffer[%s]\n",buffer);
					printf("SIZE [%d]",size);
					printf("WRITE %d\n",writebytes);
				}
				fchmod (fp,perm);/*Set recieved permissions*/
				close(fp);
				
			}
		}
		else if (strcmp(argv[3],"put") == 0)
		{
			struct stat st;
			int ret = stat(argv[4],&st);
			int size = st.st_size;
			
			if(ret == -1)
			{
				printf("File Does Not Exist\n");
				return(0);
			}
			if(argv[5] == NULL || atoi(argv[5]) < 0 || atoi(argv[5]) > 7)
			{ 
				printf("Invalid Permissions Argument\n");
				return(0);
			}
			if (st.st_mode & S_IRUSR) { /* read permission, owner */
			
			int perm = atoi(argv[5]);
			packet req = {PUT,size,perm,""};
			
			strcpy(req.text,argv[4]);
			write(S,&req,sizeof(packet));/*Write request to server socket*/
			
			char buffer[BUFSIZE];
			int fp = open(req.text,O_RDONLY);/*open local file for reading*/

			int writebytes = 0;
			int readbytes = 0;
			int totalbytes = 0;
			memset(buffer,'\0',BUFSIZE);


			while(totalbytes < size && (readbytes = read(fp,&buffer,BUFSIZE)) > 0 )/*read from file until reached total size*/
			{
				writebytes = write(S,&buffer,readbytes);/*write until reached final size*/
				memset(buffer,'\0',BUFSIZE);
				totalbytes += writebytes;
			    
				if(DEBUG == 1){
					printf("Write %d\n",writebytes);
					printf("READ %d\n",readbytes);
				}
			}
			
			fflush(stdout);
			close(fp);
			packet res;
			
			read(S,&res,sizeof(packet));/*read response from server*/
			
			if(res.type == ERR)
			{
				printf("%s",res.text);
			}
			if(res.type == ACK)
			{
				printf("\nSuccessful Transfer\n");
			}
			
			}
			else{
				printf("Do Not Have Read permissions\n");
			}
		}
		else{
			printf("Improper Argument\n");
			return(0);
		}
		close(S);
		return(0);
	}
	else if(port == 3002)/*exec services*/
	{
		packet req = {EXE,0,0,""};
		strcpy(req.text,argv[3]);
		write(S,&req,sizeof(packet));/*write teh request packet with the filename to exec*/
		
		packet res;
		read(S,&res,sizeof(packet));
		if(res.type == ACK)
		{
			char buffer[MAXSTR];
			int bytesread = 0;
			while((bytesread = read(S,&buffer,MAXSTR)) > 0)/*read all that exec file may output*/
			{
			      write(1,&buffer,bytesread);
			}
			printf("\n");
		}
		if(res.type == ERR)
		{
				printf("%s",res.text);
		}
	}

	close(S);

	return(0);

}
