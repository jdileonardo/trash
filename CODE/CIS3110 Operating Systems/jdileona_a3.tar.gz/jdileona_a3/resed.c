/* Filename: resec.c
 * Author: Julian Di Leonardo
 * ID:0675743
 * Date:April 3rd, 2011
 * Class: CIS 3110
 * Assignment 3(Part 2 of 2)
 * 
 * Description: The server which communicates with the client
 */
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <netdb.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <time.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <sys/resource.h>

#define ERROR(x) do { perror(x); exit(1); } while(0)

#define NAME       257
#define BUFSIZE    257
#define MAXPENDING 10
#define MAXSTR 1025
#define DEBUG 0

typedef enum { LIS, GET, PUT, EXE, ACK, ERR } PacketType;

typedef struct
{
    PacketType type;
    int size;
    int perm;
    char text[MAXSTR];
} packet;


void SIGCHLD_handler (int signum);

int createSockets(int port);
void connectionHandle(int S);
void gettime(int NS);
void fileservice(int NS);
void execservice(int NS);
int S0,S1,S2;				/* fds for sockets */

struct sockaddr_in serv_addr, cli_addr;

int main(int argc, char *argv[])
{
	signal(SIGCHLD,SIG_IGN);
	int pid = fork();
	
	if ( pid != 0 ) {
		if(DEBUG == 1)
		printf("Current PID [%d]\n", pid);
		exit(1);
	}
	
	S0 = createSockets(3000);/*Create the 3 sockets to communicate on*/
	S1 = createSockets(3001);
	S2 = createSockets(3002);
	
	while(1){/*Acts as a select(), cycles through the sockets looking for a connection on the other end*/
	connectionHandle(S0);
	connectionHandle(S1);
	connectionHandle(S2);
	usleep(50000);
	}
	return(0);
}

int createSockets( int port )
{
	int S;	/* fd for socket */
	/*
	 * Get socket - INTERNET DOMAIN - TCP
	 */
	if ((S = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		ERROR("server: socket");
	 bzero((char *) &serv_addr, sizeof(serv_addr));
	 fcntl(S,F_SETFL,O_NONBLOCK);/*Set to nonblocking*/

	/*
	 * Bind to server address - in network byte order
	 */
	 serv_addr.sin_family = AF_INET;
	 serv_addr.sin_addr.s_addr = INADDR_ANY;
	 serv_addr.sin_port = htons(port);

	/*
	 * Bind socket to port/addr
	 */
	if (bind(S, (struct sockaddr *) &serv_addr,
              sizeof(serv_addr)) < 0)
		ERROR("server: bind");

	/*
	 * Listen on this socket
	 */
	if (listen(S,MAXPENDING) < 0)
		ERROR("server: listen");
		
		return(S);
}

void connectionHandle(int S)
{
	int NS;	/* fd for connected socket */
	bzero((char *) &cli_addr, sizeof(cli_addr));
	socklen_t clilen;
	clilen = sizeof(cli_addr);

	NS = accept(S,(struct sockaddr *) &cli_addr, &clilen);/*Greater than zero if theirs a connect*/

	if (NS >= 0 && S == S0)/*checks to see if the supplied socket from the while loop matches the global defined one*/
	{
		gettime(NS);/*time service function*/
	}
		
	if (NS >= 0 && S == S1)
	{
		int pid;
		if((pid = fork()) < 0)
		ERROR("server: fork");
		
		if(pid == 0)/*required child process for fileservice*/
		{
			fileservice(NS);
			close(NS);
			exit(0);
		}
	}
	if (NS >= 0 && S == S2)
	{
		execservice(NS);
	}

	close(NS);

}

void gettime(int NS)
{
	time_t rawtime;
	time ( &rawtime );
	write(NS,ctime(&rawtime),26);/*write predefined-sized string to new socket*/
}

void fileservice(int NS)
{
	packet talk;
	read(NS,&talk,sizeof(talk));
	
	if(talk.type == LIS)
	{
		FILE *fp = popen("ls -1","r");
		if(fp == NULL)
		{
			packet res = {ERR,0,0,"No Files to list\n"};
			write(NS,&res,sizeof(packet));
		}
		else{
			packet res = {ACK,0,0,""};
			write(NS,&res,sizeof(packet));
			while (fgets(talk.text, sizeof(talk.text), fp) != NULL)/*write until fp is blank*/
			{
				write(NS,&talk.text,strlen(talk.text));
			}
		}
		pclose(fp);
	}
	if(talk.type == GET)
	{
		struct stat st;
		int ret = stat(talk.text, &st);
		int size = st.st_size;
		
		if(ret == -1)
		{
			packet res = {ERR,0,0,"File Does not Exist\n"};
			write(NS,&res,sizeof(packet));
		}
		
		else if (st.st_mode & S_IRUSR) { /* read permission, owner */
		
		int perm = st.st_mode;

			packet res = {ACK,size,perm,""};/*send intial ack with size and perm to client*/
			write(NS,&res,sizeof(packet));

			char buffer[BUFSIZE];
			memset(buffer,'\0',BUFSIZE);
			int fp = open(talk.text,O_RDONLY);/*open file locally with read only permissions*/
			
			int readbytes=0;
			int writebytes=0;
			int totalbytes=0;
			
			while((readbytes = read(fp,&buffer,BUFSIZE)) > 0 && (totalbytes) < size)/*same concept as client*/
			{
			    writebytes = write(NS,&buffer,readbytes);
			    totalbytes+=readbytes;
			    memset(buffer,'\0',BUFSIZE);
			    
			    if(DEBUG == 1){
			     printf("Write %d\n",writebytes);
			     printf("READ %d\n",readbytes);
			     printf("READ TOTAL %d\n",totalbytes);
			     printf("SIZE %d\n",size);
			    }
			}
			
			
			
			close(fp);
		}
		else
		{
			packet res = {ERR,0,0,"Do Not Have Read Permissions\n"};
			write(NS,&res,sizeof(packet));
		}
		
	}
	if(talk.type == PUT)
	{
		int size = talk.size;
		char buffer[BUFSIZE];
		int perm = talk.perm;
		
		
		int fp = open(talk.text,O_WRONLY | O_CREAT,S_IWUSR);/*create a file with write permissions*/
		int readbytes = 0;
		memset(buffer,'\0',BUFSIZE);
		//
		int writebytes = 0;
		int totalbytes=0;

		
		while((totalbytes < size) && ((readbytes = read(NS,&buffer,BUFSIZE)) > 0))/*same idea as client*/
		{
			writebytes = write(fp,&buffer,readbytes);
			memset(buffer,'\0',BUFSIZE);
			totalbytes += readbytes;
			if(DEBUG == 1){
				printf("Totalbytes = %d\n",totalbytes);
				printf("Readbytes = %d\n",readbytes);
				printf("Condition is %d\n", (totalbytes < size));
			}
		}

		if (perm == 7)/*permission analysis, as no other method worked for me(i realize its sloppy)*/
			fchmod(fp, S_IRWXU);
		else if (perm == 6)
			fchmod(fp, S_IWUSR|S_IRUSR);
		else if (perm == 5)
			fchmod(fp, S_IRUSR|S_IXUSR);
		else if (perm == 4)
			fchmod(fp, S_IRUSR);
		else if (perm == 3)
			fchmod(fp, S_IWUSR|S_IXUSR);
		else if (perm == 2)
			fchmod(fp, S_IWUSR);
		else if (perm == 1)
			fchmod(fp, S_IXUSR);
		else 
			fchmod(fp, 00000);

		close(fp);
		
		if(writebytes == size)/*if we wrote as much as the size*/
		{
			packet res = {ACK,0,0,""};
			write(NS,&res,sizeof(packet));
		}
		else if(writebytes == -1){/*if we werent able to write*/
			packet res = {ERR,0,0,"Do Not Have Write Permissions, File May Exist\n"};
			write(NS,&res,sizeof(packet));
		}
		
	}
}
void execservice(int NS)
{
	packet req;
	read(NS,&req,sizeof(req));/*read req, get filename to exec*/
	char *args[MAXSTR];
	int i = 1;
	args[0] = strtok(req.text," ");/*gets filename*/
	
	
	struct stat buf;
	int ret = stat(args[0],&buf);
	if(ret == -1)
	{
		packet res = {ERR,0,0,"File Doesnt Exist\n"};
			write(NS,&res,sizeof(packet));
	}
	if (buf.st_mode & S_IXUSR) /* execute/search permission, owner */
	{  
		packet res = {ACK,0,0,""};
		write(NS,&res,sizeof(packet));
		
		while(1)/*parse rest of the args*/
		{
			args[i] = strtok(NULL," ");
			if(args[i] == NULL)
			{
					break;
			}
			i++;
		}
	
		int pid = fork();/*requried to exec*/
		if (pid == 0)
		{
			close(1);
			dup2(NS,1);
			close(NS);		
			execv(args[0],args);
			exit(0);
		}
	}
	else{
			packet res = {ERR,0,0,"Do Not Have Exec Permissions\n"};
			write(NS,&res,sizeof(packet));
	}
}
void SIGCHLD_handler( int signum )/*handler for zombie processes*/
{
	 wait3(NULL,WNOHANG,NULL);
}
