Author: Julian Di Leonardo
ID:0675743
Date:April 3rd, 2011
Class: CIS 3110

FILES:

resec.c - the client which make the initial request
resed.c - the server which handles requests, returns correct info.

Compilation:
Open a terminal;
type: make, make all, or make rese
type: .resed

and in the other
type: ./resec command hostname action filename misc
commands: -t -f -e
actions: list get put
misc: "filename args" or numerical value for permissions

Notes for Marker:

-The make file is setup to compile each .c file into seperate folders. This allows for easier management of the transfer of files
-Their is a DEBUG flag defined at the top of each .c file, change it to "1" to print debug messages, and "0" to hide them. 

-For my fileservice function on my server, i declared alot of the same things(e.g writebytes readbytes and totalbytes) multiple times in each if statement.
I apologize, they should be declared at the top, but once i got my code fully working with i decided not to change it in fear of breaking it. C is so finicky.
-Also the way i handled permissions on the server side for put is ugly(all the if statements). I attempted other methods but this seemed to work best for me.

Thanks for reading
