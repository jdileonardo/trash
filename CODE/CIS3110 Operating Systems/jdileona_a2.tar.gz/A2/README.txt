Author: Julian Di Leonardo
ID:0675743
DATE: March 6th, 2011
Class: 3110

Files:

scavenger.c - 'The key file, acts as the server for scheduling, and handles the spawning of foreign process's

Compilation:
-Open a terminal:
-Type make, make all, or make scavenger
type: ./scavenger IDLE=<idletime> BUSY=<busytime> USER=<usertime> pname args

Notes for marker:
Things i know work:
-Forking the server
-Forking/exec and sleeping multiple processes
-Passing the arguments to that process
-Reading in from "w"
-Creation of and Writing to a database file
-Proper clearing when issuing a kill from terminal (eg. kill -2 scavenger), includes deletion of database

Things I can think of that don't work;
-Killing childprocess's of pnames supplied(potentially; it's been untested)
-Scheduling(big part of it i realize)
  -	I feel their is a majority of the nescessary code their to implement proper scheduling however
i've seem to come to a brick wall.


The only code i had been testing with so far was the following:

int main(int argc, char **argv)
{
  int count;
  printf("start");
	while(1)
	  {
	     count ++;
	      sleep(1);
	  }
  printf("done");

	return 0;
}

-After spending 60+ hours, I must retire. Please Be Gentle :D

Thanks for reading.