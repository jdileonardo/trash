#include <stdlib.h> 
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <signal.h>
#include <string.h>

int main(int argc, char **argv)
{
int count;
  printf("start");
	while(1)
	  {
	     count ++;
	      sleep(1);
	  }
  printf("done");

	return 0;
}
