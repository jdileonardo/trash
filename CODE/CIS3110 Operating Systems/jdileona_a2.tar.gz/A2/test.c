//      test.c
//      
//      Copyright 2011 Julian Di Leonardo <juliandileonardo@ubuntu>
//      
//      This program is free software; you can redistribute it and/or modify
//      it under the terms of the GNU General Public License as published by
//      the Free Software Foundation; either version 2 of the License, or
//      (at your option) any later version.
//      
//      This program is distributed in the hope that it will be useful,
//      but WITHOUT ANY WARRANTY; without even the implied warranty of
//      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//      GNU General Public License for more details.
//      
//      You should have received a copy of the GNU General Public License
//      along with this program; if not, write to the Free Software
//      Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//      MA 02110-1301, USA.

#include <stdlib.h> 
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <signal.h>
#include <string.h>

char *buffer,*temp = NULL;

size_t len = 256;

int main(int argc, char **argv)
{
			
			int result;
			float loadaverage,numofusers;
			FILE *fp = popen("w -s -f","r");
			getline(&buffer,&len,fp);
			//strcpy(temp,buffer);
			fputs(buffer,stdout);
			 char *eat;
			eat = strtok(buffer, ",");
			eat = strtok(NULL,",");
			result = sscanf(eat," %f%*s",&numofusers);
			eat = strtok(NULL,":");
			eat = strtok(NULL,",");
			result = sscanf(eat," %f",&loadaverage);
			printf("[%f][%f]\n",numofusers,loadaverage);

			getline(&buffer,&len,fp);//Eat the Title
			int lowestidle;
			int i;

			for(i = 0; i < numofusers; i++)
			{
				int a,b;
				char time[15],name[25];
				char ID = ' ';
				int idletime;
				getline(&buffer,&len,fp);
				fputs(buffer,stdout);
				printf("\n");
				eat = strtok(buffer," ");
				eat = strtok(NULL," ");
				eat = strtok(NULL," ");
				result = sscanf(eat,"%s",time);
				result = sscanf(time, "%d%*c%d%c",&a,&b,&ID);
				printf("//[%d][%d][%c]//",a,b,ID);
				eat = strtok(NULL," ");
				result = sscanf(eat,"%s",name);
				printf("[THETIME:%s][%s]",time,name);
				if(NULL != strstr(name,"./test"))
				{
					printf("@@@@\n");
				continue;	
				}
				
				
				
				if((ID == ('m')))//hours:mins
				{
					idletime = ((a*360)+(b*60));	
				}
				
				if((ID == ('s')))//seconds.miliseconds
				{
					idletime = (a + (b/60));
				}
				if ((ID == ' '))//mins:seconds
				{
					idletime = 	((a*60)+b);
				}

				printf("Calculated[%d]\n",idletime);
				if( i == 0)
				{
					lowestidle = idletime;
				}
				if(idletime < lowestidle)
				{
					lowestidle = idletime;
				}

		}
			printf("WOO[%d]",lowestidle);
	return 0;
}

