#include <stdlib.h> 
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <signal.h>
#include <string.h>
#include <sys/file.h>

float idleload,busyload,usertime;
char *pname;
int dbend;
int numoftries = 0;
void writeDB();
void readDB();
void clearall();
void serverSched();

void SIGQUIT_handler(int signum);


struct processRecord record;
struct processRecord record2;
FILE *fp;
char *buffer;
size_t len = 256;

struct processRecord{
	float idle;
	float busy;
	float user;
	float PID;
};

int main(int argc, char *argv[])
{
  signal(SIGHUP, SIGQUIT_handler);
  signal(SIGABRT, SIGQUIT_handler);
  signal(SIGINT, SIGQUIT_handler);
  signal(SIGQUIT, SIGQUIT_handler);
  signal(SIGTERM, SIGQUIT_handler);

	//START:Parse through the arguments and grab good stuff
	fp = fopen("/tmp/database","ab");
	fclose(fp);
	
    char *eat;
    eat = strtok(argv[1], "IDLE=");
    record.idle = atof(strtok(eat," "));
    printf("IdleLoad: %f\n", record.idle);
    eat = strtok(argv[2], "BUSY=");
    record.busy = atof(strtok(eat," "));
    printf("Busyload: %f\n", record.busy);
    eat = strtok(argv[3], "USER=");
    record.user = atof(strtok(eat," "));
    printf("UserLoad: %f\n", record.user);
    
    pname = argv[4];
    printf("Processname: %s\n",pname);
	//END
	FILE *fp = popen("ps -ef | grep scavenger | grep -vc grep","r");
	getline(&buffer,&len,fp);
	pclose(fp);
	int serveralive = atoi(buffer);
	//printf("[[%d]]",serveralive);
	//Start: Check if File exists or not//
	int test= getpid();
	printf("INITIALPID:[%d]\n",test);
	if (serveralive < 2)
	{
		int pid = fork();
		printf("OUTPUTOFFORK: [%d]\n",pid);
			if (pid == 0)
			{
				setsid();
				//serverflag = 0;
				printf("I am the Server(child)\n");
				serverSched();
			}
	}
	 //End
	 
	 int pid = fork();
	printf("PID for pname: %d\n",pid);
	if( pid == 0){//exec the process
		setsid();
		//Create Args for Exec
		char ** args = malloc (sizeof (char*) * (argc - 3));
		for (int i = 0; i < argc - 4; i++) {
			args [i] = argv [i + 4];
			}
		args [argc - 4] = NULL;
		
		  execv(argv[4],args);
		
		printf("Execing Pname\n");
	}
	
	else{//im a parent
	  sleep(1);
		int test = kill(pid,SIGSTOP);
		printf("KILLRETURN[%d]",test);
		record.PID = pid;
		writeDB();
		printf("Parent of Pname\n");
	 }
	 

   return(0); 
}
void serverSched(){
	
	fp = fopen("/tmp/database","ab");
	flock(fileno(fp),LOCK_EX);
	flock(fileno(fp),LOCK_UN);
	fclose(fp);
	
	FILE *fp = popen("ps -ef | grep scavenger | grep -vc grep","r");
	getline(&buffer,&len,fp);
	pclose(fp);

	int serveralive = atoi(buffer);
	while(serveralive == 2)
	{
		int counter = 0;
		while(counter < 60)
		{
			//START:Call W, get num of users and idle time, and load average
			char *buffer = NULL;
			int result;
			float loadaverage,numofusers;
			FILE *fp = popen("w -s -f","r");
			getline(&buffer,&len,fp);
			fputs(buffer,stdout);
			 char *eat;
			eat = strtok(buffer, ",");
			eat = strtok(NULL,",");
			result = sscanf(eat," %f%*s",&numofusers);
			eat = strtok(NULL,":");
			eat = strtok(NULL,",");
			result = sscanf(eat," %f",&loadaverage);
			//result = sscanf(buffer," %*s %*s %*s %*s %f %*s %*s %*s %f",&numofusers,&loadaverage);
			//fputs(buffer,stdout);
			printf("Users[%f]LoadAVG[%f]\n",numofusers,loadaverage);

			getline(&buffer,&len,fp);//Eat the Title
			int lowestidle;
			int i;

			while(getline(&buffer,&len,fp) != -1)
			{
				int a,b;
				char time[15],name[100];
				char ID = ' ';
				int idletime;
				//getline(&buffer,&len,fp);
				fputs(buffer,stdout);
				printf("\n");
				eat = strtok(buffer," ");
				eat = strtok(NULL," ");
				eat = strtok(NULL," ");
				result = sscanf(eat,"%s",time);
				result = sscanf(time, "%d%*c%d%c",&a,&b,&ID);
				printf("//A[%d]B[%d]ID[%c]//",a,b,ID);
				eat = strtok(NULL," ");
				result = sscanf(eat,"%s",name);
				printf("[THETIME:%s]Name[%s]",time,name);
				if(NULL != strstr(name,"w -f -s"))
				{
					printf("@@@@\n");
				continue;	
				}
				
				if((ID == ('m')))//hours:mins
				{
					idletime = ((a*360)+(b*60));	
				}
				
				if((ID == ('s')))//seconds.miliseconds
				{
					idletime = (a + (b/60));
				}
				if ((ID == ' '))//mins:seconds
				{
					idletime = ((a*60)+b);
				}

				printf("CalculatedTime[%d]\n",idletime);
				
				if( i == 0)
				{
					lowestidle = idletime;
				}
				i++;
				if(idletime < lowestidle)
				{
					lowestidle = idletime;
				}
			pclose(fp);
		}
			printf("LowestIdle[%d]\n",lowestidle);
			//END
			
			//Start: Get info from DB, maybe at top
			sleep(2);
			counter = counter+ 2;
			readDB();
			//Busy--suspend all//sigstop
			if((lowestidle < record2.user) || (loadaverage > record2.busy))
			{
				printf("BUSY");
				sleep(1);
				killpg(record2.PID,SIGSTOP);
				
				counter = counter - 5; //counter shit
			}
			//Inactive//shit is allowed to run
			else if((lowestidle >= record2.user) && (loadaverage < record2.idle))
			{
				printf("INACTIVE");
				sleep(1);
				killpg(record2.PID,SIGCONT);
				counter = counter +1;
			}
			
				sleep(6);
				counter = counter + 6;
		}	
	}
}

void writeDB(){//Create and write to the DB
		printf("WRITING\n");
		//flock and fileno(fp)
		 fp = fopen("/tmp/database","ab");
		 fseek(fp,0,SEEK_END);
		 flock(fileno(fp),LOCK_EX);
		 struct processRecord temp;
		 temp.idle = record.idle;
		 temp.busy = record.busy;
		 temp.user = record.user;
		 temp.PID = record.PID;
		 fwrite(&temp, sizeof(struct processRecord), 1, fp);
		 flock(fileno(fp),LOCK_UN);
		 fclose(fp);
}
void readDB(){//Read from the DB
	fp = fopen("/tmp/database","rb");
	flock(fileno(fp),LOCK_EX);
	 printf("READING\n");
	 fseek(fp,0,SEEK_END);
	 dbend = ftell(fp);
	 fseek(fp,0,SEEK_SET);
	 while(ftell(fp) != dbend)
	 {
		fread(&record2, sizeof(struct processRecord), 1, fp);
	 
		if((kill(record2.PID,0)) == -1)
		{
			continue; 
			numoftries++;
		}
	
		else
		{
			printf("success"); 
			break;
		}
	}
		
	 if((numoftries*16) == dbend)
	{
		printf("Killemall");
		clearall();
		//end entire program
	}
		 printf("[%f][%f][%f][%f]",record2.idle,record2.busy,record2.user,record2.PID);
		 flock(fileno(fp),LOCK_UN);
		 fclose(fp);
}

void clearall(){
  fp = fopen("/tmp/database","rb");
	flock(fileno(fp),LOCK_EX);
	fseek(fp,0,SEEK_END);
	 dbend = ftell(fp);
	 fseek(fp,0,SEEK_SET);
	 while(ftell(fp) != dbend)
	 {
		fread(&record2, sizeof(struct processRecord), 1, fp);
		kill(record2.PID,SIGKILL);
	 }
	  flock(fileno(fp),LOCK_UN);
	  fclose(fp);
	  remove("/tmp/database");
	  exit(0);
	}
	
void SIGQUIT_handler(int signum)
{
  clearall();
}



