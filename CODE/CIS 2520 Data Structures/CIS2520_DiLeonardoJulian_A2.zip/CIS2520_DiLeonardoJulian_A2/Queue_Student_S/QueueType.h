/*********************************************************************
 * FILE NAME: Queuetype.h
 * PURPOSE: Queue structure
 * AUTHOR: Julian Di Leonardo
 * DATE: Sunday October 16th 2011
 *********************************************************************/
#include "StudentInterface.h"
typedef Student Item;

#define MAXQUEUESIZE 4
typedef struct {
	Item items[MAXQUEUESIZE];
	int size;
	int head;
} Queue;
