/*********************************************************************
 * FILE NAME: myprogram.c
 * PURPOSE: Tests functionality of Queue
 * AUTHOR: Julian Di Leonardo
 * DATE: Sunday October 16th 2011
 *********************************************************************/
 
#include "QueueInterface.h"
#include <stdio.h>
#include <stdlib.h>


static void showListSize (Queue *Q) {
	if(Empty(Q)) printf("Queue is empty; ");
	else printf("Queue is not empty; ");
	if(Full(Q)) printf("Queue is full; ");
	else printf("Queue is not full; ");
	printf("Queue is of length %d:\n",Length(Q));
}


static void showListContent (Queue *Q) {
	int i;
	Student S;
	for(i=0;i<Length(Q);i++){
		Head(Q,&S);
		printf("\t%s %d%%\n",NameOfStudent(S),GradeOfStudent(S));
		Dequeue(Q);
		Enqueue(S,Q);
		FreeStudent(&S);
	}
}


int main(void) {
	FILE *test;
	char s[20];
	int position, grade;

	Student S;
	Queue Q;

	Initialize(&Q);
	showListSize(&Q);
	showListContent(&Q);

	test=fopen("test.txt","r");
	while(fscanf(test,"%s %d",s,&position)==2) {
		if(strcmp(s,"Insert")==0) {
			fscanf(test,"%s %d",s,&grade);
			InitializeStudent(s,grade,&S);
			Enqueue(S,&Q);
			FreeStudent(&S);
		}
		if(strcmp(s,"Delete")==0)
			Dequeue(&Q);
		showListSize(&Q);
		showListContent(&Q);
	}

	fclose(test);
	Destroy(&Q);
	return EXIT_SUCCESS;
}

