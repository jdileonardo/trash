#include "QueueType.h"

 /*********************************************************************
 * FUNCTION NAME: Initialize
 * PURPOSE: Sets the Queue to default values
 * ARGUMENTS: Queue variable
 *********************************************************************/
extern void Initialize (Queue *Q);
/*********************************************************************
 * FUNCTION NAME: Enqueue
 * PURPOSE: Adds item to Queue
 * ARGUMENTS: Queue variable, Item variable
 *********************************************************************/
extern void Enqueue (Item X, Queue *Q);
/*********************************************************************
 * FUNCTION NAME: Dequeue
 * PURPOSE: Removes item to Queue
 * ARGUMENTS: Queue variable, Item variable
 *********************************************************************/
extern void Dequeue (Queue *Q);
/*********************************************************************
 * FUNCTION NAME: Full
 * PURPOSE: Determines if Queue is full
 * ARGUMENTS: Queue Variable
 *********************************************************************/
extern int Full (Queue *Q);
/*********************************************************************
 * FUNCTION NAME: Empty
 * PURPOSE: Determines if Queue is Empty
 * ARGUMENTS: Queue Variable
 *********************************************************************/
extern int Empty (Queue *Q);
/*********************************************************************
 * FUNCTION NAME: Length
 * PURPOSE: Determines Queue Length
 * ARGUMENTS: Queue Variable
 *********************************************************************/
extern int Length (Queue *Q);
/*********************************************************************
 * FUNCTION NAME: Head
 * PURPOSE: Fills variable with head of queue variable
 * ARGUMENTS: Queue Variable, Item variable
 *********************************************************************/
extern void Head (Queue *Q, Item *X);
/*********************************************************************
 * FUNCTION NAME: Destroys
 * PURPOSE: Destorys queue and queue entries
 * ARGUMENTS: Queue Variable
 *********************************************************************/
extern void Destroy (Queue *Q);
