/*********************************************************************
 * FILE NAME: Queueimplementation.c
 * PURPOSE: Server end of Queue implementation
 * AUTHOR: Julian Di Leonardo
 * DATE: Sunday October 16th 2011
 *********************************************************************/
#include "QueueInterface.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>


#define DEBUG


static void copyItem (Item *Y, Item X) {
	InitializeStudent(NameOfStudent(X),GradeOfStudent(X),Y);
}


static void destroyItem (Item *X) {
	FreeStudent(X);
}


void Initialize (Queue *Q) {
	Q->size=0;
	Q->head=0;

}


void Enqueue (Item X, Queue *Q) {

    int position = Q->head + Q->size;
    if(position >= MAXQUEUESIZE){
        position = position-MAXQUEUESIZE;
    }
    Q->items[position] = X;
    Q->size++;
}


void Dequeue (Queue *Q) {

    destroyItem(&Q->items[Q->head]);
    Q->head++;
    if(Q->head == MAXQUEUESIZE){
        Q->head = 0;
    }
    Q->size--;

}


int Full (Queue *Q) {
	return Q->size==MAXQUEUESIZE;
}


int Empty (Queue *Q) {
	return Q->size==0;
}


int Length (Queue *Q) {
	return Q->size;
}


void Head (Queue *Q, Item *X) {

    copyItem(X,Q->items[Q->head]);
}


void Destroy (Queue *Q) {
	int i;
	for(i=Q->head;i<MAXQUEUESIZE;i++)
		destroyItem(&Q->items[i]);
}

