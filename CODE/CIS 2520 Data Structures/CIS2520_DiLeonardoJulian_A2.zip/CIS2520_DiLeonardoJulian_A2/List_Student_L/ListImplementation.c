/*********************************************************************
 * FILE NAME: ListImplementation.c
 * PURPOSE: One-way linked implementation of the Student List ADT.
 * AUTHOR: Julian Di Leonardo
 * DATE: Sunday October 16th 2011
 * NOTES: . Some functions are static (they are auxiliary functions
 *          with local scope; they are not visible outside the file).
 *        . Only the first two functions will need to be modified
 *          if the type of the list items (here, Student) changes.
 *        . Only the other functions will need to be modified if
 *          the implementation of the List ADT changes.
 *        . For preconditions and postconditions,
 *          see the sequential implementation.
 *********************************************************************/


#include "ListInterface.h"
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <stdio.h>



static void copyItem (Item *Y, Item X) {
	InitializeStudent(NameOfStudent(X),GradeOfStudent(X),Y);
}


static void destroyItem (Item *X) {
	FreeStudent(X);
}


static ListNode *moveTo (int position, List *L) {
	int i;
	ListNode *p=L->first;
	for(i=0;i<position;i++) p=p->next;
	return p;
}


void Initialize (List *L) {
	L->size=0;
	L->first=NULL;

	assert(Empty(L));
	assert(!Full(L));
	assert(Length(L) == 0);
}


void Insert (Item X, int position, List *L) {

    #ifdef DEBUG
    assert(position >= 0);
    assert(position <= Length(L));
    assert(!Full(L));

    int prevSize = L->size;
    #endif

	ListNode *p, *q;
	L->size++;
	q=(ListNode *)malloc(sizeof(ListNode));
	copyItem(&q->item,X);
    //q->next = NULL;

	if(position==0) {
		q->next=L->first;
		L->first=q;
	}
	else {
		p=moveTo(position-1,L);
		q->next=p->next;
		p->next=q;
	}

    #ifdef DEBUG
	assert(!Empty(L));
	assert(Length(L)- 1 == prevSize);

	Item temp;
	Peek(position, L, &temp);
	assert(strcmp(temp.name,X.name) == 0);
	assert(temp.grade == X.grade);
	#endif
}


void Delete (int position, List *L) {
	ListNode *p, *q;

    #ifdef DEBUG
    assert(position >= 0);
    assert(position <= Length(L));
    assert(!Empty(L));

    int prevSize = L->size;
    #endif

	if(position==0) {
		q=L->first;
		L->first=q->next;
	}
	else {
		p=moveTo(position-1,L);
		q=p->next;
		p->next=q->next;
	}

	destroyItem(&q->item);
	free(q);
	L->size--;

    #ifdef DEBUG
	assert(!Full(L));
	assert(Length(L) + 1 == prevSize);
	#endif
}


int Full (List *L) {
	return L->size==MAXLISTSIZE;
}


int Empty (List *L) {
	return L->size==0;
}


int Length (List *L) {
	return L->size;
}


void Peek (int position, List *L, Item *X) {

    #ifdef DEBUG
    assert(position >= 0);
    assert(position <= Length(L));
    assert(!Empty(L));
    #endif
	ListNode *p;
	p=moveTo(position,L);
	copyItem(X,p->item);
}


void Destroy (List *L) {
	int i;
	ListNode *p, *q;

	p=L->first;
	for(i=0;i<L->size;i++) {
		q=p;
		p=p->next;
		destroyItem(&q->item);
		free(q);
	}
}

void Reverse(List *L){

    ListNode *head = L->first;
    ListNode *body = head->next;

    if(body == NULL){
        return;
    }

    List temp;
    temp.first = body;

    Reverse(&temp);
    head->next->next = head;
    head->next = NULL;

    L->first = temp.first;
}
