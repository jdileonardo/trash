/*********************************************************************
 * FILE NAME: myProgram.c
 * PURPOSE: Test program for Stack implementations.
 * AUTHOR: Julian Di Leonardo
 * DATE: October 16th 2011
 * NOTES: This program uses test data recorded in a text file
 *        (see test.txt). The use of such a file was not required,
 *        but is very practical.
 *********************************************************************/

#include "StackInterface.h"
#include <stdio.h>
#include <stdlib.h>

void fill(Stack *S,FILE *fp) {
    char c;
    Item X;
    while((c = fgetc(fp)) != EOF )
    {
        if(c == '\n'){
            break;
        }
        else{
            X = atoi(&c);
            Push(X,S);
        }

    }
}

int main(void) {
	FILE *fp;
	Stack Number1;
	Stack Number2;
	Stack Sum;

	Initialize(&Number1);
	Initialize(&Number2);
	Initialize(&Sum);

	fp=fopen("test.txt","r");

	fill(&Number1,fp);
	fill(&Number2,fp);

    fclose(fp);

    int maxSize = Length(&Number1);

    if(Length(&Number2) > Length(&Number1)){
        maxSize = Length(&Number2);
    }

    int i;
    int carry = 0;
    Item X,Y,Z;
    for(i = 0; i < maxSize; i++)
    {
        if(Empty(&Number1)){
            X = 0;
        }
        else{
            Top(&Number1,&X);
            Pop(&Number1);
        }

        if(Empty(&Number2)){
            Y = 0;
        }
        else{
            Top(&Number2,&Y);
            Pop(&Number2);
        }
        //printf("X[%d],Y[%d],C[%d]",X,Y,carry);
        Z = X + Y + carry;
        if (Z >9){
            carry = 1;
            Z = Z-10;
        }
        else{
            carry = 0;
        }

        Push(Z,&Sum);
    }
    int sumSize = Length(&Sum);
    printf("ANSR ");
    for(i = 0; i < sumSize-1; i++){//On Windows, in order to get correct answer, it must be for(i = 0; i < sumSize; i++)
        Item Num;
        Top(&Sum,&Num);
        printf("%d",Num);
        Pop(&Sum);
    }
    printf("\nREAL 6376120394793988623001460399866772483849149904325361\n");
    Destroy(&Number1);
	Destroy(&Number2);
	Destroy(&Sum);

    return EXIT_SUCCESS;
}

