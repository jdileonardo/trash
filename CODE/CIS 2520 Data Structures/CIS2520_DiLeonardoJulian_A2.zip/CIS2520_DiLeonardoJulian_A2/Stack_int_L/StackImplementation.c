/*********************************************************************
 * FILE NAME: StackImplementation.c
 * PURPOSE: Server end of Stack
 * AUTHOR: Julian Di Leonardo
 * DATE: October 16th 2011
 *********************************************************************/
#include "StackInterface.h"
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <stdio.h>

void Initialize (Stack *S) {
	S->size=0;
	S->first=NULL;
}


void Push (Item X, Stack *S) {

	ListNode *q;
	S->size++;
	q=(ListNode *)malloc(sizeof(ListNode));
	q->item = X;
    q->next=S->first;
    S->first=q;
}


void Pop (Stack *S) {
	ListNode *q;

    q=S->first;
    S->first=q->next;

	free(q);
	S->size--;
}


int Full (Stack *S) {
	return S->size==1024;
}


int Empty (Stack *S) {
	return S->size==0;
}


int Length (Stack *S) {
	return S->size;
}


void Top (Stack *S, Item *X) {
	*X = S->first->item;
}


void Destroy (Stack *S){
	int i;
	ListNode *p, *q;

	p=S->first;
	for(i=0;i<S->size;i++) {
		q=p;
		p=p->next;
		free(q);
	}
}
