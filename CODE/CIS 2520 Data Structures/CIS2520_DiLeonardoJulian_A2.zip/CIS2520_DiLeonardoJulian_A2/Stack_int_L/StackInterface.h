#include "StackType.h"

/*********************************************************************
 * FUNCTION NAME: Initialize
 * PURPOSE: Gives the list default values
 * ARGUMENTS: The address of the Stack
 *********************************************************************/
extern void Initialize (Stack *S);
/*********************************************************************
 * FUNCTION NAME: Push
 * PURPOSE: Adds item to top of stack
 * ARGUMENTS: Item to be pushed, Stack to be pushed on
 *********************************************************************/
extern void Push (Item X, Stack *S);
/*********************************************************************
 * FUNCTION NAME: Pop
 * PURPOSE: Removes item from top of stack
 * ARGUMENTS: Item to be popped,The address of the Stack
 *********************************************************************/
extern void Pop (Stack *S);
/*********************************************************************
 * FUNCTION NAME: Full
 * PURPOSE: Determins if Stack is full or not
 * ARGUMENTS: The address of the Stack
 *********************************************************************/
extern int Full (Stack *S);
/*********************************************************************
 * FUNCTION NAME: Empty
 * PURPOSE: Determins if stack if empty
 * ARGUMENTS: The address of the Stack
 *********************************************************************/
extern int Empty (Stack *S);
/*********************************************************************
 * FUNCTION NAME: Length
 * PURPOSE: returns length of stack
 * ARGUMENTS: The address of the Stack
 *********************************************************************/
extern int Length (Stack *S);
/*********************************************************************
 * FUNCTION NAME: Top
 * PURPOSE: Fills item passed in with top of stack info
 * ARGUMENTS: The address of the Stack, item to be filled
 *********************************************************************/
extern void Top (Stack *S, Item *X);
/*********************************************************************
 * FUNCTION NAME: Destory
 * PURPOSE: Frees and deletes all info in stack
 * ARGUMENTS: The address of the Stack
 *********************************************************************/
extern void Destroy (Stack *S);
