/*********************************************************************
 * FILE NAME: StackType.h
 * PURPOSE: Concrete data structure definition of Stack List.
 * AUTHOR: Julian Di Leonardo
 * DATE: October 16th 2011
 *********************************************************************/



typedef int Item;

typedef struct ListNodeTag {
	Item item;
	struct ListNodeTag *next;
} ListNode;

typedef struct {
	int size;
	ListNode *first;
} Stack;
