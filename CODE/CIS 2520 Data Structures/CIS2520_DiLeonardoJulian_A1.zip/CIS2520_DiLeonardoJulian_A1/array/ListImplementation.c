#include "ListInterface.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define DEBUG


int numOfLists = 0;


void Initialize (List *L)
{
    L->count = 0;
    int temp = numOfLists;
    numOfLists++;

    #ifdef DEBUG
    if(temp+1 != numOfLists){
       printf("List was not initialized");
       exit(0);
    }
    #endif
}


void Insert (Item X, int position, List *L)
{
    position--;
    #ifdef DEBUG
    if((position>MAXLISTSIZE-1))
    {
        printf("That position is too large");
        exit(0);
    }
    if(position<0){
        printf("Position is a negative number");
        exit(0);
    }
    if(Full(L) == 1){
        printf("Cant Insert, the List is full");
        exit(0);
    }
    if(numOfLists == 0){
        printf("Cant Insert, List has not been initialized");
        exit(0);
    }
    if(position>L->count)
    {
        printf("Cant place there, will create a gap in the list");
        exit(0);
    }
    #endif

        int i;
        for(i = MAXLISTSIZE-1; i > position; i-- )
        {
            L->items[i] = L->items[i-1];
        }
        L->items[position] = X;

        int temp = L->count;
        L->count += 1;


    #ifdef DEBUG
    if(temp+1 != L->count){
        printf("Item was not added");
        exit(0);
    }
    #endif

}

void Delete (int position, List *L)
{
    position--;
    #ifdef DEBUG
    if(numOfLists == 0){
        printf("Cant Delete, List has not been initialized");
        exit(0);
    }
    if((position > MAXLISTSIZE-1))
    {
        printf("That position is too large");
        exit(0);
    }
    if(position<0){
        printf("Position is a negative number");
        exit(0);
    }
    if(position >= L->count)
    {
        printf("Cant delete there, nothing exists");
        exit(0);
    }
    if(Empty(L) == 1)
    {
        printf("Cant Delete, the List is empty");
        exit(0);
    }
    #endif
    int i;
    FreeStudent(&L->items[position]);
    for( i = position; i<MAXLISTSIZE-1; i++)
    {
        L->items[i] = L->items[i+1];
    }
    int temp = L->count;
        L->count -= 1;


    #ifdef DEBUG
    if(temp-1 != L->count){
        printf("Item was not deleted");
        exit(0);
    }
    #endif
}

int Full (List *L)
{
    #ifdef DEBUG
        if(numOfLists == 0){
        printf("No Lists Exist");
        exit(0);
    }
    #endif
    if(L->count == 4)
    {
        //We are full
        return(1);
    }
    else
    {
        return(0);
    }

}

int Empty (List *L)
{
    #ifdef DEBUG
      if(numOfLists == 0){
        printf("No Lists Exist");
        exit(0);
    }
    #endif
    if(L->count == 0)
    {
        //We are empty
        return(1);
    }
    else
        return(0);
}

int Length (List *L)
{
    #ifdef DEBUG
    if(numOfLists == 0){
        printf("No Lists Exist");
        exit(0);
    }
    #endif
    return(L->count);
}

void Peek (int position, List *L, Item *X)
{
    position--;
    #ifdef DEBUG
    if(numOfLists == 0){
        printf("No Lists Exist");
        exit(0);
    }
    if((position>MAXLISTSIZE-1))
    {
        printf("That position is too large");
        exit(0);
    }
    if(position<0){
        printf("Position is a negative number");
        exit(0);
    }
    if(Empty(L) == 1)
    {
        printf("Cant Peek, the List is empty");
        exit(0);
    }
    if(position>L->count)
    {
        printf("Cant peek there, doesnt exist");
        exit(0);
    }
    #endif

    strcpy(X->name,L->items[position].name);
    X->grade = L->items[position].grade;
}
void Destroy (List *L)
{
    #ifdef DEBUG
    if(numOfLists == 0){
        printf("No Lists Exist");
        exit(0);
    }
    #endif
    int temp = numOfLists;
    numOfLists--;
    int i;
    for(i = 0; i < L->count; i++){
        FreeStudent(&L->items[i]);
    }
    //free(&L);
    #ifdef DEBUG
    if( temp-1 != numOfLists){
        printf("List was not deleted");
        exit(0);
    }
    #endif
}
