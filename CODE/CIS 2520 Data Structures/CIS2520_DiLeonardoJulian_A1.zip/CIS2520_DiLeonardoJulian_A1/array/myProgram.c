#include "ListInterface.h"
#include <stdio.h>

void ListStatus(List Class);

int main() 
{

    List Class;
    Item student;

    Initialize(&Class);
    ListStatus(Class);
    InitializeStudent("John",75,&student);
    Insert(student,1,&Class);
    ListStatus(Class);
    InitializeStudent("Mary",80,&student);
    Insert(student,1,&Class);
    ListStatus(Class);
    InitializeStudent("Pete",90,&student);
    Insert(student,3,&Class);
    ListStatus(Class);
    InitializeStudent("Liz ",85,&student);
    Insert(student,3,&Class);
    ListStatus(Class);

    Delete(1,&Class);
    ListStatus(Class);
    Delete(2,&Class);
    ListStatus(Class);
    Delete(2,&Class);
    ListStatus(Class);
    Delete(1,&Class);
    ListStatus(Class);

    Destroy(&Class);

    return(0);

}

void ListStatus(List Class)
{
    if(Empty(&Class) == 1)
    {
        printf("List is empty; ");
    }
    else
    {
        printf("List is not empty; ");
    }

    if(Full(&Class) == 1)
    {
        printf("List is full; ");
    }
    else
    {
        printf("List is not full; ");
    }

    printf("List is of length %d\n",Length(&Class));

    int i;
    for(i = 0; i < Length(&Class); i++)
    {
        Item temp;


        Peek(i+1,&Class,&temp);

        printf("    %s %d\n",NameOfStudent(temp),GradeOfStudent(temp));
    }


}
