/*********************************************************************
* FILE NAME:StudentInterface.h
* PURPOSE: Manipulates the Student type
* AUTHOR:Julian Di Leonardo
* DATE:September 25th 2011
* NOTES:Template created by Prof. Matsakis
*********************************************************************/
#include "StudentType.h"
/*********************************************************************
* FUNCTION NAME:InitializeStudent 
* PURPOSE:Fills student variable with name and grade
* ARGUMENTS:string, grade, student variable
* RETURNS:None
* REQUIRES: Grade to be valid, name to be entered
* ENSURES: None
* NOTES: Try a grade over 100 or under 0, also try entering nothing for the name
*********************************************************************/
extern void InitializeStudent (char *name, int grade, Student *S);
/*********************************************************************
* FUNCTION NAME:NameofStudent
* PURPOSE:returns the name of a student
* ARGUMENTS:Student variable
* RETURNS:Student Name
* REQUIRES: None/or Student needs to be initialized(i guess you could check to see if s.name doesnt have garbage data?)
* ENSURES: None
* NOTES:Its difficult to tell if a s.name has been put through initializestudent, and name of student is only called after a peek.
*********************************************************************/
extern char *NameOfStudent (Student S);
/*********************************************************************
* FUNCTION NAME:GradeofStudent
* PURPOSE:returns the grade of a student
* ARGUMENTS:Student variable
* RETURNS:Grade of the student
* REQUIRES: Same as NameofStudent
* ENSURES: None
* NOTES: Same as nameofstudent
*********************************************************************/
extern int GradeOfStudent (Student S);
/*********************************************************************
* FUNCTION NAME:FreeStudent
* PURPOSE:to remove malloc mem for the student
* ARGUMENTS:Student variable
* RETURNS:none
* REQUIRES: same as NameofStudent
* ENSURES: None
* NOTES: Same as NameofStudent
*********************************************************************/
extern void FreeStudent (Student *S);
