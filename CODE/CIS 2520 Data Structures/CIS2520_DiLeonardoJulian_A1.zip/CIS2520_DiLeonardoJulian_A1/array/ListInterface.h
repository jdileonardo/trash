/*********************************************************************
* FILE NAME:ListInterface.h
* PURPOSE:Provides function declarations for ListImplementation.c
* AUTHOR:Julian Di Leonardo
* DATE:September 25th 2011
* NOTES:Template created by Prof. Matsakis
*********************************************************************/
#include "ListType.h"

/*********************************************************************
* FUNCTION NAME:Initialize
* PURPOSE:Creates a List
* ARGUMENTS: Pointer to a List variable
* RETURNS:None
* REQUIRES: None
* ENSURES: List wss Initialized
* NOTES: The use of numOfLists is for support of multiple List type variables.
*********************************************************************/
extern void Initialize (List *L);
/*********************************************************************
* FUNCTION NAME:Insert
* PURPOSE:To insert a Student/Item variable into the List at a given position
* ARGUMENTS:Item, Position, List
* RETURNS: None
* REQUIRES: Position being <4 but >0 and not  >SizeofList+1. List must exist, and List cannot be full
* ENSURES: The list increases by 1
* NOTES:To test conditions, try inserting before the list has been created, a large number for a position, a negative number for position. A position within the size limit but greater than the current size of the list, and when the list is full
*********************************************************************/
extern void Insert (Item X, int position, List *L);
/*********************************************************************
* FUNCTION NAME:Delete
* PURPOSE:To remove an item from the list
* ARGUMENTS:Position, List
* RETURNS:None
* REQUIRES: List must exist, List cannot be empty, Position cant be out of scope, Position cant leave a gap, by placing greater than the sizeofthelist.
* ENSURES: List size decreases by 1
* NOTES:TO test conditions, try deleting while a list doesnt exist, or an empty list, try invalid positions like 9000, -500, or if the size is 1 try 4.
*********************************************************************/
extern void Delete (int position, List *L);
/*********************************************************************
* FUNCTION NAME:Full
* PURPOSE:To if the list is full
* ARGUMENTS:List variable
* RETURNS: 1 on full, 0 or not
* REQUIRES: A List to exist
* ENSURES: None
* NOTES:Try testing with various sizes of a list, and with a list not being initialized
*********************************************************************/
extern int Full (List *L);
/*********************************************************************
* FUNCTION NAME:Empty
* PURPOSE:Checks if list is empty
* ARGUMENTS:List Variable
* RETURNS:None
* REQUIRES: List to exist
* ENSURES: None
* NOTES:Try testing with various sizes of a list, and with a list not being initialized
*********************************************************************/
extern int Empty (List *L);
/*********************************************************************
* FUNCTION NAME:Length
* PURPOSE: to return the length of the list
* ARGUMENTS:List variable
* RETURNS:size of list
* REQUIRES:List to exist
* ENSURES:None
* NOTES:To test, try with different lengths, and try with or without a list existing.
*********************************************************************/
extern int Length (List *L);
/*********************************************************************
* FUNCTION NAME:Peek
* PURPOSE:To view and place a Item in the list to the item being passed in
* ARGUMENTS:Position, Length variable Item variable
* RETURNS: None
* REQUIRES: List exists, list is not empty, position is in within validity
* ENSURES: X is filled with actual data
* NOTES:Test with if the list is existing or not, and if its empty or not. Also test with a variety of position variables
*********************************************************************/
extern void Peek (int position, List *L, Item *X);
/*********************************************************************
* FUNCTION NAME:Destroy
* PURPOSE:Empties and destroys a list
* ARGUMENTS:Position, List Item
* RETURNS: None
* REQUIRES: List to exist, valid position, List not to be empty
* ENSURES: X was filled
* NOTES:Test the same way insert and delete were
*********************************************************************/
extern void Destroy (List *L);

