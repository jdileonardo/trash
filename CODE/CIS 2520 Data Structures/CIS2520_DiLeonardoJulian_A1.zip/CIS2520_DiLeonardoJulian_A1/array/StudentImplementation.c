#include <stdlib.h>
#include <string.h>
#include "StudentInterface.h"


void InitializeStudent (char *name, int grade, Student *S) {
	/* your code here */
	#ifdef DEBUG
	if(grade > 100 || grade < 0){
        printf("Invalid grade"); 
        exit(0);
	}
	if(name == ""){
        printf("Invalid name");
        exit(0);
	}
	#endif
	strcpy(S->name,name);
	S->grade = grade;
}

char *NameOfStudent (Student S) {
	/* your code here */
	char *temp = malloc(sizeof(S.name));
	strcpy(temp,S.name);
	return(temp);

}

int GradeOfStudent (Student S) {
	return(S.grade);
}

void FreeStudent (Student *S) {
	//free(S->name);
	//free(S);
}
