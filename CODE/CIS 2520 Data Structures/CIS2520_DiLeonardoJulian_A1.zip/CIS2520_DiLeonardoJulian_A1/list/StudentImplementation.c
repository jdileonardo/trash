#include <stdlib.h>
#include <string.h>
#include "StudentInterface.h"

void InitializeStudent (char *name, int grade, Student *S){
	S->name = name;
	S->grade = grade;
}

char *NameOfStudent (Student S){
	return(S.name);
}

int GradeOfStudent (Student S) {
	return(S.grade);
}

void FreeStudent (Student *S) {
	free(S->name);
	free(S);
}
