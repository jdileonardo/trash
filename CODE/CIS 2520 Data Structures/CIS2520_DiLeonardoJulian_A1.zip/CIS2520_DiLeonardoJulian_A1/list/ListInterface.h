#include "ListType.h"

extern void Initialize (List *L);
extern void Insert (Item X, int position, List *L);
extern void Delete (int position, List *L);
extern int Full (List *L);
extern int Empty (List *L);
extern int Length (List *L);
extern void Peek (int position, List *L, Item *X);
extern void Destroy (List *L);
