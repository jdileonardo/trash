#include "StudentType.h"
extern void InitializeStudent (char *name, int grade, Student *S);
extern char *NameOfStudent (Student S);
extern int GradeOfStudent (Student S);
extern void FreeStudent (Student *S);
