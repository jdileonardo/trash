#include "ListInterface.h"
#include <stdlib.h>
#include <stdio.h>

void Initialize (List *L)
{
    L->size = 0;
    L->first = NULL;
}

void Insert (Item X, int position, List *L)
{
    position--;

    ListNode *Node = malloc(sizeof(ListNode));
    Node->item = X;
    Node->next = NULL;

    ListNode *temp = NULL;

    temp = L->first;

    //printf("[%s]",X.name);

    if(position == 0)
    {
        L->first = Node;
        Node->next = temp;
    }
    else
    {
        int i;
        for(i = 0; i < position-1; i++)
        {
            temp = temp->next;
        }
        Node->next = temp->next;
        temp->next = Node;
    }

    L->size += 1;

}

void Delete (int position, List *L)
{
    position--;


    ListNode *temp = L->first;
    ListNode *disconnected;
    if(position == 0){
        L->first = temp->next;
        free(temp);
    }
    else{

        int i;
        for(i = 0; i < position-1; i++){
            temp = temp->next;
        }
        disconnected = temp->next;
        temp->next = disconnected->next;
        free(disconnected);
    }
    L->size -= 1;
}

int Full (List *L)
{
    if(L->size == MAXLISTSIZE)
    {
        return(1);
    }
    else
    {
        return(0);
    }
}

int Empty (List *L)
{
    if(L->size == 0)
    {
        return(1);
    }
    else
    {
        return(0);
    }
}

int Length (List *L)
{
    return(L->size);
}

void Peek (int position, List *L, Item *X)
{
    position--;
    ListNode *temp = NULL;
    temp = L->first;

    int i;
    for(i = 0; i < position; i++)
    {
        temp = temp->next;
    }

    X->name = temp->item.name;
    X->grade = temp->item.grade;
}

void Destroy (List *L)
{
    int size = L->size;
    int i;
    for(i = 0; i < size; i++){
        Delete(size-i,L);
    }
    free(L);

}
